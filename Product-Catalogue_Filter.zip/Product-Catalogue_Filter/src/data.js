const products = [
  { id: 1, name: "Blue T-Shirt", category: "Clothing", price: 150, inStock: true },
  { id: 2, name: "Black Jeans", category: "Clothing", price: 300, inStock: false },
  { id: 3, name: "Red Sneakers", category: "Shoes", price: 500, inStock: true },
  { id: 4, name: "Wireless Mouse", category: "Accessories", price: 250, inStock: true },
  { id: 5, name: "Office Chair", category: "Furniture", price: 1200, inStock: false },
  { id: 6, name: "White Polo Shirt", category: "Clothing", price: 180, inStock: true },
  { id: 7, name: "Blue Jeans", category: "Clothing", price: 280, inStock: true },
  { id: 8, name: "Gaming Headset", category: "Accessories", price: 450, inStock: true },
  { id: 9, name: "Wooden Desk", category: "Furniture", price: 800, inStock: true },
  { id: 10, name: "Black Sneakers", category: "Shoes", price: 350, inStock: false },
  { id: 11, name: "Leather Wallet", category: "Accessories", price: 120, inStock: true },
  { id: 12, name: "Green Hoodie", category: "Clothing", price: 220, inStock: true }
];

export default products;